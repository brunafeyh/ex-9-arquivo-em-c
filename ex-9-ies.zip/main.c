/*9. Fac¸a um programa que receba dois arquivos do usuario, e crie um terceiro arquivo com ´
o conteudo dos dois primeiros juntos (o conte ´ udo do primeiro seguido do conte ´ udo do ´
segundo).

BRUNA CAROLINA DA SILVA FEYH 
22/08/2023
*/
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

#define MAX 1000


int parq(char *s, char str[], char str2[]){
    FILE *f;
    f = fopen(s, "w");
    if(f == NULL) return errno;
    
    fprintf(f, "%s\n", str);
    fprintf(f, "%s", str2);
 
    fclose(f);
    return 0;
}
int lerarq(char *s, char str[]){
    FILE *f;
    f = fopen(s, "r");
    if(f == NULL) return errno;
    
    fscanf(f, "%[^EOF]", str);
 
    fclose(f);
    return 0;
}
int main()
{
    char ch[MAX], ch2[MAX];

    int erro, tam1, tam2;;
    
    erro = lerarq("arq.txt" , ch);
    if(erro != 0) printf("erro de leitura: %d\n", erro);
    
    tam1 = strlen(ch);
    
    erro = lerarq("texto.txt" , ch2);
    if(erro != 0) printf("erro de leitura: %d\n", erro);
    
    tam2 = strlen(ch2);
    
    erro = parq("saida.txt", ch, ch2);
    if(erro != 0) printf("erro de gravação: %d\n", erro);
    
   
    return 0;
}
